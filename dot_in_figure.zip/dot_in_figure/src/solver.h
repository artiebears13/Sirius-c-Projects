#include <vector>


int solver(std::vector<float> x_points, std::vector<float> y_points, float x, float y);