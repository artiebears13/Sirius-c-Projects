class Line{
public:
    int x1, x2, y1, y2;

    Line(int x_begin, int y_begin, int x_end, int y_end) ;

    int get_pos(int x, int y);

};


